CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `test`@`%` 
    SQL SECURITY DEFINER
VIEW `customerorderdetails` AS
    SELECT 
        `c`.`CustomerID` AS `CustomerID`,
        `c`.`Name` AS `Name`,
        `o`.`OrderID` AS `OrderID`,
        `o`.`Total` AS `Total`,
        `m`.`MenuName` AS `MenuName`,
        `mi`.`Course` AS `Course`,
        `mi`.`Starter` AS `Starter`
    FROM
        (((`customers` `c`
        JOIN `orders` `o` ON ((`c`.`CustomerID` = `o`.`CustomerID`)))
        JOIN `menus` `m` ON ((`o`.`MenuID` = `m`.`MenuID`)))
        JOIN `menuitems` `mi` ON ((`m`.`MenuItemID` = `mi`.`MenuItemID`)))