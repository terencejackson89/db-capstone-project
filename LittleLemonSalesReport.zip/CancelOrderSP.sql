DELIMITER //
CREATE PROCEDURE CancelOrder(id INT)
BEGIN
UPDATE Orders SET OrderStatusID = 4 WHERE OrderID = id;
SELECT CONCAT("Order ", id, " has been cancelled.") "Confirmation Message";
END //
DELIMITER ;

CALL CancelOrder(4);