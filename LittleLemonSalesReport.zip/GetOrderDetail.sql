PREPARE GetOrderDetail FROM 'SELECT OrderID, Quantity, Total FROM Orders WHERE OrderID = ?';

SET @id = 5;
EXECUTE GetOrderDetail USING @id;