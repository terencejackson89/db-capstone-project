CREATE PROCEDURE GetMaxQuantity()
SELECT MAX(Quantity) "Total Quantity In Order" FROM Orders;

CALL GetMaxQuantity()