CREATE VIEW OrdersView AS
SELECT OrderID, Quantity, Total FROM Orders WHERE Quantity > 2;

SELECT * FROM OrdersView;