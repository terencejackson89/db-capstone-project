## Creating AddValidBooking procedure

DELIMITER //

CREATE PROCEDURE AddValidBooking(book_date DATE, tbl_no INT)
BEGIN
    START TRANSACTION;
        INSERT INTO Bookings (BookingDate, TableNo) VALUES (book_date, tbl_no);
        IF EXISTS (SELECT 1 FROM Bookings WHERE BookingDate = book_date AND TableNo = tbl_no) THEN 
          SELECT CONCAT("Table ", tbl_no, " is already booked. Booking cancelled") "Booking Status";
          ROLLBACK;
		ELSE
          SELECT "Booking Successful";
          COMMIT;
        END IF;
END //

DELIMITER ;

## Call Procedure on set of values
CALL AddValidBooking('2022-12-17', 6);
