## Creating procedure for adding a new booking

DELIMITER //
CREATE PROCEDURE AddBooking(book_id INT, book_date DATE, tbl_no INT, cust_id INT, emp_id INT)
BEGIN
    INSERT INTO Bookings VALUES (book_id, book_date, tbl_no, cust_id, emp_id);
    SELECT "New booking added" AS Confirmation;
END //
DELIMITER ;

## Calling to insert new booking

CALL AddBooking(5, '2022-12-30', 4, 2, 6);