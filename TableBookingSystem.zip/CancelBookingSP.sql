## Procedure to cancel/remove booking

DELIMITER //

CREATE PROCEDURE CancelBooking(book_id INT)
BEGIN
    DELETE FROM Bookings WHERE BookingID = book_id;
    SELECT CONCAT("Booking ", book_id, " is cancelled") AS Confirmation;
END //

DELIMITER ;

## Call procedure to remove booking

CALL CancelBooking(5);