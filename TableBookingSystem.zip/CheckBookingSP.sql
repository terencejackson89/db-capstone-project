## Creating CheckBooking Procedure

DELIMITER //

create procedure CheckBooking(b_date DATE, tbl_no INT)
BEGIN
   DECLARE exists_var INT;
   SELECT count(1) INTO exists_var FROM Bookings WHERE EXISTS(SELECT 1 FROM Bookings WHERE BookingDate = b_date AND TableNo = tbl_no);
   SELECT CASE WHEN exists_var = 0 THEN CONCAT("Table ", tbl_no, " is not booked.") ELSE CONCAT("Table ", tbl_no, " is already booked.") END "Booking Status";
END //

DELIMITER ;

## Call to Stored Procedure
CALL CheckBooking('2022-11-12', 3);