## Create procedure to update booking date

DELIMITER //

CREATE PROCEDURE UpdateBooking(book_id INT, book_date DATE)
BEGIN
    UPDATE Bookings SET BookingDate = book_date WHERE BookingID = book_id;
    SELECT CONCAT("Booking ", book_id, " updated.") AS Confirmation;
END //

DELIMITER ;

## Calling procedure for an existing booking

CALL UpdateBooking(4, '2022-12-13');